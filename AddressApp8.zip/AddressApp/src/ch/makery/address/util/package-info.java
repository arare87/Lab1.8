/**
 * 
 */
/**
 * @author MSI
 *
 */
package ch.makery.address.util;